<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOutAppTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('out_app_transactions', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('user_id')->nullable();
            $table->unsignedInteger('tour_id')->nullable();
            $table->string('client_ip_address')->nullable();
            $table->integer('amount');
            $table->integer('pricing_plan_id')->default(1);
            $table->string('status',50)->nullable();
            $table->string('ref_id',255)->nullable();
            $table->string('payment_host',255)->nullable();
            $table->string('card_4_digit',255)->nullable();
            $table->string('card_holder',255)->nullable();
            $table->string('card_id',255)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('out_app_transactions');
    }
}
