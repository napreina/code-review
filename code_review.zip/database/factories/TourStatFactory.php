<?php

use App\Tour;
use App\TransactionLog;
use Faker\Generator as Faker;

$factory->define(App\TourStat::class, function (Faker $faker) {

    $tour=Tour::all()->random();
    $transaction=TransactionLog::where('tour_id',$tour->id)->get()->random();
    return [
        'downloads' => $faker->numberBetween(0, 9999),
        'time_spent' => $faker->numberBetween(0, 9909),
        'actions' => $faker->numberBetween(0, 500),
        'tour_id' => $tour->id,
        'yyyymmdd'=>$transaction->created_at->format('Ymd'),
        'final' => 1,
    ];
});
