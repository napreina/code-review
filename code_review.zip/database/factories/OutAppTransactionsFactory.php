<?php

use App\Client;
use App\OutAppTransactions;
use App\PricingPlan;
use App\Tour;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(OutAppTransactions::class, function (Faker $faker) {
 
    return [
        'tour_id'=>Tour::all()->random()->id,
        'status'=>'succeeded',
        'client_ip_address'=>$faker->ipv4,
        'amount'=>$faker->numberBetween(2,100),
        'created_at'=>$faker->dateTimeBetween('-15 months'),
        'pricing_plan_id'=>PricingPlan::all()->random()->plan_id

    ];
});
