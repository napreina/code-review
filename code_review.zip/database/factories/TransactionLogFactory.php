<?php

use App\Client;
use App\PricingPlan;
use App\Tour;
use App\TransactionLog;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(TransactionLog::class, function (Faker $faker) {
 
    return [
        'user_id' => Client::all()->random()->id,
        'tour_id'=>Tour::all()->random()->id,
        'transaction_type'=>'redemption',
        'client_ip_address'=>$faker->ipv4,
        'num_tokens'=>$faker->numberBetween(2,100)*-1,
        'balance'=>$faker->numberBetween(2,100),
        'created_at'=>$faker->dateTimeBetween('-6 months'),
        'pricing_plan_id'=>PricingPlan::all()->random()->plan_id

    ];
});
