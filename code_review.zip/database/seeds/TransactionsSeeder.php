<?php

use App\TransactionLog;
use Illuminate\Database\Seeder;

class TransactionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         create(TransactionLog::class,[],2000);
    }
}