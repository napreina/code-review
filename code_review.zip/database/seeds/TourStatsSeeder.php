<?php

use App\TourStat;
use App\TransactionLog;
use Illuminate\Database\Seeder;

class TourStatsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i=0; $i < 1000; $i++) { 
            try {
                create(TourStat::class,[],2);
            } catch (\Throwable $th) {
               
            }
        }
        
    }
}