<?php

use App\OutAppTransactions;
use App\TransactionLog;
use Illuminate\Database\Seeder;

class OutAppTransactionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         create(OutAppTransactions::class,[],2000);
    }
}