## Access Points and Routing

The API is broken off into 3 different sections: Admin, CMS and Mobile.  Routes are separated accordingly, and broken into their corresponding files in the /routes/ directory.

Each API has it's own prefix like this:
```
https://api.wejunket.com/cms/
https://api.wejunket.com/admin/
https://api.wejunket.com/mobile/
```
