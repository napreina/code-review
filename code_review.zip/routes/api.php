<?php
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
*/

Route::post('auth/login/facebook', 'AuthController@facebook')->name('facebook.login');
Route::post('auth/login/google', 'AuthController@google')->name('google.login');
Route::post('auth/login/apple-sign-up', 'AuthController@signUpApple')->name('apple.sign.up.in');
//Route::post('auth/login/apple-url', 'AuthController@getAppleLoginUrl')->name('apple.login.url');
//Route::get('oauth/apple/callback', 'AuthController@handleAppleCallback')->name('oauth.apple.callback');
Route::post('auth/login', 'AuthController@login');
Route::post('auth/signup', 'AuthController@signup');
Route::post('auth/forgot-password', 'ResetPasswordController@forgot');
Route::post('auth/reset-password', 'ResetPasswordController@reset');
Route::post('confirm-email', 'ConfirmEmailController@confirm')->name('confirm-email');

Route::get ('tours', 'TourController@getAllTours');
Route::post('purchase-junket-from-peek', 'TourController@purchaseJunketFromPeek')->name('purchase-junket-from-peek')->middleware('auth.apikey');
Route::post('purchase-junket-from-fareharbor-test/{tour}', 'TourController@purchaseJunketFromFareHarborTest')->name('purchase-junket-from-fareharbor-test');
Route::post('purchase-junket-from-fareharbor/{tour}', 'TourController@purchaseJunketFromFareHarbor')->name('purchase-junket-from-fareharbor');
Route::post('purchase-junket-from-thirdparty', 'TourController@purchaseJunketFromThirdparty')->name('purchase-junket-from-thirdparty')->middleware('auth.apikey');

Route::post('create-payment-intent', 'PaymentController@createPaymentIntent')->name('create-payment-intnent')->middleware('auth.apikey');
Route::post('verify-payment-intent', 'PaymentController@verifyPaymentIntent')->name('verify-payment-intnent')->middleware('auth.apikey');
Route::post('register-payment-domain', 'PaymentController@registerPaymentDomain')->name('verify-payment-intnent')->middleware('auth.apikey');
Route::get('get-checkout-url', 'PaymentController@getCheckoutUrl')->name('get-checkout-url')->middleware('auth.apikey');

 Route::get('stripe-checkout-success',  'PaymentController@stripeCheckoutSuccess')->name('stripe-checkout-success');
 Route::get('stripe-checkout-fail',  'PaymentController@stripeCheckoutFailure')->name('stripe-checkout-fail');


Route::middleware(['jwt.auth', 'active'])->group(function () {
    Route::get('auth/session', 'AuthController@userSession');
    Route::delete('auth/facebook', 'AuthController@facebookDetach')->name('facebook.detach');
    Route::post('auth/facebook/attach', 'AuthController@facebookAttach')->name('facebook.attach');
});

Route::middleware(['jwt.refresh'])->group(function () {
    Route::get('auth/refresh', function () {
        return response(null, 204);
    });
});
