<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ClientBankAccountAlert extends Mailable
{
    use SerializesModels;


    /**
     * The user that has just joined.
     *
     * @var \App\Client
     */
    public $client;



    /**
     * Create a new message instance.
     *
     * @param mixed $user
     * @return void
     */
    public function __construct($client)
    {
        $this->client = $client;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $view = 'mail.bank-account-alert';
        return $this->subject("Please Connect your bank account")
            ->markdown($view)
            ->with('client', $this->client);
    }
}
