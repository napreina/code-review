<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ClientFinancialReport extends Mailable
{
    use SerializesModels;


    public $data;
    /**
     * The user that has just joined.
     *
     * @var \App\Client
     */
    public $client;



    /**
     * Create a new message instance.
     *
     * @param mixed $user
     * @return void
     */
    public function __construct($data, $client)
    {
        $this->data = $data;
        $this->client = $client;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $view = 'mail.financial-report';
        // if (!@count($this->data['reviews'])) {
        //     $view = 'mail.financial-report-no-reviews';
        // }

        return $this->subject("Financial report for: {$this->data['start_date']} - {$this->data['end_date']}")
            ->view($view)
            ->with('data', $this->data)
            ->with('client', $this->client);
    }
}
