<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class BankAccountConnectReport extends Mailable
{
    use SerializesModels;



    /**
     * The user that has just joined.
     *
     * @var \App\Client
     */
    private $user;


    /**
     * Status of bank account connecting process.
     *
     * @var \App\Client
     */
    private $status;

    /**
     * errors reported from stripe on bank account connecting process .
     *
     * @var \App\Client
     */
    private $errors;

    /**
     * Create a new message instance.
     *
     * @param mixed $user
     * @return void
     */

    public function __construct($user, $status, $errors)
    {
        $this->status = $status;
        $this->errors = $errors;
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $msg = '';
        $msg2 = '';
        $url = '';
        $btnText = 'Click for more Analytics';
        if ($this->status == 'VERIFIED') {
            $msg = 'Your bank account connected successfully.  You will be paid after your earnings reach $100 each month.';
            $msg2 = 'Login to your account to view data for each junket.';
            $url = '/#/login';
        } else if ($this->status == 'NOTVERIFIED') {

            $msg = "Bank account verification failed .";
            $msg2 = 'Sign in to your account to complete the bank account connection.';
            $btnText = 'Sign In';
            $url = '/#/profile';
            if ($this->errors && @count($this->errors)) {
                $msg .= '<br><br><br><strong>Errors:</strong><br>';
                foreach ($this->errors as  $error) {
                    $msg .= '<p style="color:red">' . $error['reason'] . '</p>';
                }
            }
        }
        $view = 'mail.bank-connect-report';
        return $this->subject("Bank Account")
            ->view($view)
            ->with('msg2', $msg2)
            ->with('url', $url)
            ->with('btnText', $btnText)
            ->with('msg', $msg);
    }
}
