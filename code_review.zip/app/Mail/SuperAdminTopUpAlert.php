<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SuperAdminTopUpAlert extends Mailable
{
    use SerializesModels;


    


    /**
     * Create a new message instance.
     *
     * @param void 
     * @return void
     */
    public function __construct($data)
    {
        $this->data=$data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $view = 'mail.super-admin-top-up-alert';
        return $this->subject("Top-up Alert")
            ->markdown($view)
            ->with('data', $this->data);
    }
}
