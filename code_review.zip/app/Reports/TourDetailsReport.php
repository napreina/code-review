<?php

namespace App\Reports;

use App\Activity;
use App\OutAppTransactions;
use App\TransactionLog;
use App\PricingPlan;
use App\Tour;
use Carbon\Carbon;

class TourDetailsReport extends BaseReport
{
    /**
     * The begin date.
     *
     * @var string
     */
    protected $start_date;

    /**
     * The end date.
     *
     * @var string
     */
    protected $end_date;

    /**
     * Filter the results to between two dates.
     *
     * @param string $start
     * @param string $end
     * @return $this
     */
    public function forDates($start, $end)
    {
        $this->start_date = $start;
        $this->end_date = $end;

        return $this;
    }

    /**
     * Run the report and return the results.
     *
     * @return array
     */
    public function run()
    {
        $plan_percents = PricingPlan::PERCENTS;

        // if no date range set, get the first date of stats
        if (empty($this->start_date)) {
            $firstRecord = $this->tour->stats()->orderBy('yyyymmdd')->first();
            if (empty($firstRecord)) {
                return [];
            }
            $date = date('m/d/Y', strtotime($firstRecord->yyyymmdd));
            $this->forDates($date, date('m/d/Y', strtotime('now')));
        }

        $results = $this->tour->stats()
            ->betweenDates($this->start_date, $this->end_date)
            ->orderBy('yyyymmdd')
            ->get();
        return [
            'data' => $results->map(function ($item) use ($plan_percents) {
                $google_apple_commission = 30;
                $downloads = Activity::select('device_id')
                    ->where('action', 'start_stop')
                    ->where('actionable_id', $item->tour_id)
                    ->where('actionable_type', 'App\Tour')
                    ->where('begin_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->get();
                $totalTime = Activity::where('action', 'start_stop')
                    ->where('actionable_id', $item->tour_id)
                    ->where('actionable_type', 'App\Tour')
                    ->where('begin_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->get()
                    ->sum(function ($activity) {
                        $begin = Carbon::parse($activity->begin_at);
                        $end = Carbon::parse($activity->end_at);
                        return $end->diffInSeconds($begin);
                    });
                $outappData = OutAppTransactions::where('status', 'succeeded')
                    ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->where('tour_id', $item->tour_id)
                    ->get();
                $out_app_revenue = $outappData->sum('amount') / 100;

                $out_app_earning = $outappData->sum(function ($t) use ($plan_percents) {
                    $total = round(($t->amount / 100) * $plan_percents[$t->pricing_plan_id]['out-app'] / 100);
                    return $total;
                });
                $revenues = TransactionLog::where('transaction_type', 'redemption')
                    ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->where('tour_id', $this->tour->id)
                    ->get()
                    ->sum('num_tokens');

                $earning = TransactionLog::where('transaction_type', 'redemption')
                    ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->where('tour_id', $this->tour->id)
                    ->get()
                    ->sum(function ($t) {
                        $revenue_split = PricingPlan::find($t->pricing_plan_id)->revenue_split;
                        return $t->num_tokens * $revenue_split / 100;
                    });

                return [
                    'yyyymmdd' => $item->yyyymmdd,
                    'actions' => (int) $item->actions,
                    'downloads' => count($downloads),
                    'out_app_earning' => round($out_app_earning),
                    'out_app_revenue' => round($out_app_revenue),
                    'revenues' => -1 * $revenues,
                    'earning' => $earning * (100 - $google_apple_commission) / 100 * -1,
                    'time' => $totalTime,
                    'tour_id' => (int) $item->tour_id
                ];
            })
        ];
    }
}
