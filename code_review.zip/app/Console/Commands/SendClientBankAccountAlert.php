<?php

namespace App\Console\Commands;

use App\Activity;
use App\Analytics\AnalyticsSummarizer;
use App\Client;
use App\FinancialReportLog;
use App\Mail\ClientFinancialReport;
use App\Mail\WelcomeMail;
use App\OutAppTransactions;
use App\PricingPlan;
use App\Review;
use App\Action;
use App\Mail\ClientBankAccountAlert;
use App\Payout;
use Illuminate\Console\Command;
use App\Tour;
use App\TransactionLog;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class SendClientBankAccountAlert extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'clients:send-bank-account-alert {user_id?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'send alert email to clients that don\'t have any valid connected  bank account.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $user_id = $this->argument('user_id');

        $clients = null;
        $this->info('Running bank account alert email job');
        if ($user_id) {
            $this->info('Fetching user with ID ' . $user_id);
            $clients = Client::where('id', $user_id)->get();
        } else {
            $clients = Client::where('verified', false)->get();
        }

        $this->info('Found ' . count($clients) . ' clients.');
        foreach ($clients  as $client) {
            try {
                $this->info('proccessing clintd ID :' . $client->id);
                $startDate = '2010-01-01';
                $endDate = Carbon::parse('last day of 2 months ago')->format('Y-m-d');

                $lastPayout = Payout::where('user_id', $client->id)->orderBy('created_at', 'DESC')->first();
                if ($lastPayout) {
                    $startDate = Carbon::parse($lastPayout->to)->addDay(1)->format('Y-m-d');
                }
                $data = $client->calculateCosts($startDate, $endDate);

                try {
                    if ($data['payout'] >= 100) {
                        Mail::to($client->email)
                            ->send(new ClientBankAccountAlert($client));
                        $this->info('sent email successfully');
                    }
                } catch (\Throwable $th) {
                    report($th);
                    $this->info('Error on sending email :' . $th->getMessage());
                }
            } catch (\Throwable $th) {
                report($th);
                $this->info('Error on sending email :' . $th->getMessage());
            }
        }
    }
}
