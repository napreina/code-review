<?php

namespace App\Console\Commands;

use App\Activity;
use App\Analytics\AnalyticsSummarizer;
use App\Client;
use App\FinancialReportLog;
use App\Mail\ClientFinancialReport;
use App\Mail\WelcomeMail;
use App\OutAppTransactions;
use App\PricingPlan;
use App\Review;
use App\Action;
use Illuminate\Console\Command;
use App\Tour;
use App\TransactionLog;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class SendClientFinanciaReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'clients:send-financial-report {user_id?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'send monthly report to the clients regarding their income and revenue.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $startDate = Carbon::parse('first day of previous month')->format('Y-m-d');
        $endDate = Carbon::parse('last day of previous month')->format('Y-m-d');

        if ($endDate == '2020-09-30')
            return;

        $user_id = $username = $this->argument('user_id');

        $clients = null;
        $this->info('Running client financial report for ' . $startDate);
        if ($user_id) {
            $this->info('Fetching user with ID ' . $user_id);
            $clients = Client::where('id', $user_id)->get();
        } else {
            $clients = Client::all();
        }

        $this->info('Found ' . count($clients) . ' clients.');
        foreach ($clients  as $client) {
            try {
                $this->info('proccessing client ID :' . $client->id);
                if (FinancialReportLog::where('user_id', $client->id)->where('for_month', $endDate)->first()) {
                    $this->info('already sent email to the client ID :' . $client->id);
                    continue;
                }

                $this->info('sending email to ' . $client->email);
                $data = $client->calculateCosts($startDate, $endDate);

                $data['start_date'] = $startDate;
                $data['end_date'] = $endDate;
                $data['for_month'] = Carbon::parse('last day of previous month')->format('F');
                $data['downloads'] = 0;
                try {
                    foreach ($client->tours as $item) {
                        $tmp = Activity::betweenDates($startDate, $endDate)->select('device_id')
                            ->where('action', 'start_stop')
                            ->where('actionable_id', $item->id)
                            ->where('actionable_type', 'App\Tour')
                            ->get();
                        if ($tmp) {
                            $data['downloads'] += count($tmp);
                        }
                    }
                } catch (\Throwable $th) {
                    report($th);
                    $this->info('Error on sending email :' . $th->getMessage());
                }
                $data['reviews'] = Review::whereIn('tour_id', $client->tours->pluck('id')->toarray())
                    ->betweenDates($startDate, $endDate)
                    ->latest()
                    ->take(2)
                    ->get();

                try {
                    if (($data['revenue'] != 0) || ($data['downloads'] != 0)) {
                        Mail::to($client->email)->send(new ClientFinancialReport($data, $client));
                        FinancialReportLog::create(['for_month' => $endDate, 'user_id' => $client->id]);
                        $this->info('Sent successfully!');
                    } else {
                        $this->info('Both downloads and revenue are 0, skip! ');
                    }
                } catch (\Throwable $th) {
                    report($th);
                    $this->info('Error on sending email :' . $th->getMessage());
                }
            } catch (\Throwable $th) {
                report($th);
                $this->info('Error on sending email :' . $th->getMessage());
            }
        }
    }
}
