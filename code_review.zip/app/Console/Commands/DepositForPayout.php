<?php

namespace App\Console\Commands;

use App\Client;
use App\Mail\SuperAdminTopUpAlert;
use App\Payout;
use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class DepositForPayout extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deposit:topups';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'move cash from main bank account to Stripe for payout';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
 
        $this->info('Running topups ');

        $clients = Client::all();
        $totalCost = 0;
        foreach ($clients   as $client) {
            try {
                if ($client->pricing_plan_id == 6) {
                    continue;
                }
                if (!$client->verified) {
                    continue;
                }

                $startDate = '2020-04-01';
                $endDate = Carbon::parse('last day of previous month')->format('Y-m-d');


                $lastPayout = Payout::where('user_id', $client->id)->orderBy('created_at', 'DESC')->first();
                if ($lastPayout) {
                    if ($lastPayout->to == $endDate) {
                        continue;
                    }
                    $startDate = Carbon::parse($lastPayout->to)->addDay(1)->format('Y-m-d');
                }

                $costs = $client->calculateCosts($startDate, $endDate);

                if ($costs['payout'] >= 50) {
                    $totalCost += $costs['payout'];
                }
            } catch (\Throwable $th) {
                report($th);
                $this->info('Error on paying out  :' . $th->getMessage());
            }
        }
         
        
         $this->info('Total cost :' . $totalCost);
        if ($totalCost > 0) {
            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            $topup = \Stripe\Topup::create([
                'amount' => $totalCost * 100,
                'currency' => 'usd',
                'description' => 'Top-up for payouts of  ' . Carbon::parse('last day of previous month')->format('Y-m'),
                'statement_descriptor' => 'top-up ' . Carbon::parse('last day of previous month')->format('Y-m'),
            ]);
        }
        try {
            if ($totalCost > 0) {
                Mail::to(config('junket.admin_email'))
                    ->send(new SuperAdminTopUpAlert(['amount'=>$totalCost,'date'=>date('M jS')]));
                $this->info('sent email successfully');
            }
            
        } catch (\Throwable $th) {
            report($th);
            $this->info('Error on sending email :' . $th->getMessage());
        }
    }
}
