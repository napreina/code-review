<?php

namespace App\Console\Commands;

use App\Client;
use App\Payout;
use Illuminate\Console\Command;
use Carbon\Carbon;

class PayoutClients extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'clients:pay-out {user_id?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'payout to the junket owner if the income is more than $50.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $user_id  = $this->argument('user_id');
        $clients = null;
        $this->info('Running client payout for ');
        if ($user_id) {
            $this->info('Fetching user with ID ' . $user_id);
            $clients = Client::where('id', $user_id)->get();
        } else {
            $clients = Client::all();
        }
        $this->info('Found ' . count($clients) . ' clients.');

        foreach ($clients   as $client) {
            try {
                
                if($client->pricing_plan_id==6)
                {
                      $this->info('Skip system user with client ID :' . $client->id);
                      continue;
                }
                $this->info('processing client ID :' . $client->id);
                if (!$client->verified) {
                    $this->info('client ID :' . $client->id . " doesn't have valid bank account");
                    continue;
                }

                $startDate = '2020-04-01';
                $endDate = Carbon::parse('last day of previous month')->format('Y-m-d');
               
                 
                $lastPayout = Payout::where('user_id', $client->id)->orderBy('created_at', 'DESC')->first();
                if ($lastPayout) {
                    if ($lastPayout->to == $endDate) {
                        $this->info('client ID already paid :' . $client->id);
                        continue;
                    }
                    $startDate = Carbon::parse($lastPayout->to)->addDay(1)->format('Y-m-d');
                }

                $costs = $client->calculateCosts($startDate, $endDate);

                if ($costs['payout'] >= 50) {
                    $result = null;
                    try {
                       $stripe = new \Stripe\StripeClient(config('services.stripe.secret'));
              
                        $result = $stripe->transfers->create([
                            'amount' =>  $costs['payout'] * 100,
                            'currency' => 'usd',
                            'destination' => $client->stripe_id,
                            'description'=>"Your income for $startDate  - $endDate (WeJunket.com) ",
                        ]);
                         
                         
                    } catch (\Throwable $e) {
                        \Log::debug("\n payout failed with error :" . $e->getMessage() . "\n Stripe result:\n" . var_export($result, true) . "\n");
                        report($e);
                        $this->info('Error on paying out  :' . $e->getMessage());
                        continue;
                    }
                    try {
                        $payout = new Payout();
                        $payout->user_id = $client->id;
                        $payout->amount =  $result->amount;
                        $payout->from = $startDate;
                        $payout->to = $endDate;
                        $payout->strip_id =  $result->id;
                        $payout->payer = auth()->check() ? auth()->user()->id : 0;
                        $payout->payout_info = json_encode(array_merge($costs, $result->toArray()));
                        $payout->save();
                    } catch (\Throwable $th) {
                        //todo send email in this case 
                        \Log::debug("CRITICAL ERROR:Failed to save payout info see logs after this line to get more info \n");
                        \Log::debug(var_export($result, true) . "\n");
                        $this->info('Error on paying out  :' . $th->getMessage());
                        report($th);
                    }
                }
                else
                {
                    $this->info("Client ID {$client->id} payout amount:".$costs['payout']);
                }
            } catch (\Throwable $th) {
                report($th);
                $this->info('Error on paying out  :' . $th->getMessage());
            }
            $this->info("client {$client->id} proccessed.");
        }
    }
}
