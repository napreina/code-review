<?php

namespace App\Http\Controllers;

use App\Events\RedeemJunketEvent;
use App\Http\Requests\VerifyPaymentIntentRequest;
use App\Mail\BankAccountConnectReport;
use App\OutAppTransactions;
use App\Tour;
use App\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;

class PaymentController extends Controller
{

    /**
     * create stripe connect account and return url to redirect user to the stripe for starting validation
     *
     * @param  Request $req
     * @return \Illuminate\Http\Response
     */
    public function createConnectBankAccount(Request $request)
    {
        try {
            $user = auth()->user();
            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            if (!trim($user->stripe_id)) {



                $account = \Stripe\Account::create([
                    'country' => 'US',
                    'type' => 'express',
                    'email' => $user->email,
                ]);
                $user->stripe_id = $account->id;
                $user->save();
            }
            $account_links = \Stripe\AccountLink::create([
                'account' => $user->stripe_id,
                'refresh_url' => route('stripe.account.link.reauth') . '/?usr=' . urlencode(Crypt::encrypt($user->id)),
                'return_url' => route('stripe.account.link.return') . '/?usr=' .  urlencode(Crypt::encrypt($user->id)),
                'type' => 'account_onboarding',
            ]);
            return response(json_encode(['url' => $account_links->url]));
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
    }



    public function returnStripe(Request $request)
    {

        if (!$request->has('usr')) {
            return $this->fail(422, 'invalid request');
        }
        $status = 'UNKNOWN';
        $error = '';
        $account = null;
        $errors = null;

        try {

            $user = User::findOrFail(Crypt::decrypt(urldecode($request->usr)));

            $stripe = new \Stripe\StripeClient(config('services.stripe.secret'));
            $account = $stripe->accounts->retrieve(
                $user->stripe_id,
                []
            );
            try {
                \Log::debug("\n" . var_export($account, true));
            } catch (\Throwable $th) {
            }
            if ($account->details_submitted) {
                $user->verified = true;
                $user->save();
                $status = 'VERIFIED';
            } else {
                $status = 'NOTVERIFIED';
            }


            if ($account->requirements && isset($account->requirements['errors']) && isset($account->requirements['errors'][0])) {
                $errors = $account->requirements['errors'];
                $error = 'You inserted incorrect information. Check your email for details.';
                // foreach ($errors as  $value) {
                //     $error .=  $value['reason'] . ' ';
                // }
            }

            try {
                Mail::to($user->email)->send(new BankAccountConnectReport($user, $status, $errors));
            } catch (\Throwable $th) {
                report($th);
            }
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
        return redirect(config('app.cms_url') . '/profile?bank_status=' . $status . '&bank_error=' . $error);
    }
    public function reAuthStripe(Request $request)
    {
        if (!$request->has('usr')) {
            return $this->fail(422, 'invalid request');
        }
        try {

            $user = User::findOrFail(Crypt::decrypt(urldecode($request->usr)));

            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            $account_links = \Stripe\AccountLink::create([
                'account' => $user->stripe_id,
                'refresh_url' => route('stripe.account.link.reauth') . '/?usr=' . urlencode(Crypt::encrypt($user->id)),
                'return_url' => route('stripe.account.link.return') . '/?usr=' .  urlencode(Crypt::encrypt($user->id)),
                'type' => 'account_onboarding',
            ]);
            return redirect($account_links->url);
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
    }


    /**
     * create payment intent and return client secret and intent id for mobile payments (apple and google pay)
     *
     * @param  Request $req
     * @return \Illuminate\Http\Response
     */
    public function createPaymentIntent(Request $request)
    {
        try {
            $tour = Tour::find($request->junket_id);
            if (!$tour) {
                return $this->fail(422, 'Junket ID is empty.');
            }

            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));

            $intent = \Stripe\PaymentIntent::create([
                'amount' => $request->amount,
                'currency' => 'usd',
                'metadata' => ['integration_check' => 'accept_a_payment'],
            ]);

            OutAppTransactions::create(['client_ip_address' => request()->ip(), 'client_secret' => $intent->client_secret, 'amount' => $request->amount, 'status' => 'pending', 'payment_intent_id' => $intent->id, 'tour_id' => $tour->id]);
            return response(json_encode(['client_secret' => $intent->client_secret, 'payment_intent_id' => $intent->id]));
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
    }
    /**
     * verify payment intent and update DB for status 
     *
     * @param VerifyPaymentIntentRequest $req
     * @return \Illuminate\Http\Response
     */
    public function verifyPaymentIntent(VerifyPaymentIntentRequest $request)
    {
        try {
            $number_of_guests = request()->number_of_guests;
            $email = request()->email;
            $full_name = request()->full_name;
            if (!$request->payment_intent_id) {
                return $this->fail(422, 'Intent ID is empty.');
            }
            $stripe = new \Stripe\StripeClient(config('services.stripe.secret'));
            $intent = $stripe->paymentIntents->retrieve(
                $request->payment_intent_id,
                []
            );
            if (isset($intent->status) && $intent->status == "succeeded") {
                $transaction = OutAppTransactions::where('payment_intent_id', $request->payment_intent_id)->first();
                if ($transaction) {
                    try {
                        $intent =   $stripe->paymentIntents->update(
                            $request->payment_intent_id,
                            ['metadata' => ['phone' => request()->phone, 'number_of_guests' => $number_of_guests, 'full_name' =>  $full_name, 'email' => $email]]
                        );
                    } catch (Exception $e) {
                        return $this->fail(422, "Email is incorrect!");
                    }
                    $transaction->status = 'succeeded';
                    $transaction->amount = $intent->amount_received;
                    $transaction->ref_id = $intent->charges->data[0]->id;
                    $transaction->details = var_export($intent, true);
                    $transaction->save();

                    $promo_codes = [];


                    $tour = Tour::find(request()->junket_id);
                    for ($i = 0; $i < $number_of_guests; $i++) {
                        $temp = $this->getName(6);
                        array_push($promo_codes, $temp);
                        $tour->promoCodes()->create(['promo_code' => $temp, 'discount' => 100, 'quantity' => 1]);
                    }


                    try {
                        event(new RedeemJunketEvent($tour, $email, $full_name, '', $promo_codes));
                    } catch (Exception $e) {
                        return $this->fail(422, "Email is incorrect!");
                    }

                    return response()->json([
                        'promoCodes' => $promo_codes,
                        'result' => true
                    ]);
                }
            } else {
                \Log::debug('ERROR CODE:1003' . var_export($intent, true));
                return $this->fail(422, 'ERROR CODE:1003 Payment failed please contact support.');
            }
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
    }

    /**
     * Generate a random, unique, alpha-numeric string
     *
     * @param integer $n
     * @return string
     */
    private function getName($n)
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';

        for ($i = 0; $i < $n; $i++) {
            $index = rand(0, strlen($characters) - 1);
            $randomString .= $characters[$index];
        }
        return $randomString;
    }


    /**
     * add domain on stripe for being valid for apple pay 
     *
     * @param VerifyPaymentIntentRequest $req
     * @return \Illuminate\Http\Response
     */
    public function registerPaymentDomain(Request $request)
    {
        try {
            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            \Stripe\ApplePayDomain::create([
                'domain_name' => $request->domain,
            ]);
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
        return response()->json([
            'result' => true
        ]);
    }
    /**
     * add domain on stripe for being valid for apple pay 
     *
     * @param VerifyPaymentIntentRequest $req
     * @return \Illuminate\Http\Response
     */
    public function getCheckoutUrl(Request $request)
    {

        try {
            $email = request()->email;
            $full_name = request()->full_name;
            $junket_id = request()->junket_id;
            $number_of_guests = request()->number_of_guests;
            $amount = request()->amount;
            $tour = Tour::find($junket_id);
            if (empty($tour)) {
                return response()->json(['error' => 'invalid_junket_id'], 401);
            }
            $newAmount = round($tour->token_cost * 1.1 * 100 * $number_of_guests);
            if ($amount != $newAmount) {
                return response()->json(['error' => 'invalid amount'], 401);
            }

            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            $session = \Stripe\Checkout\Session::create([
                'payment_method_types' => ['card'],
                'customer_email' => $email,
                'line_items' => [[
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => [
                            'name' => $tour->title,
                        ],
                        'unit_amount' => $amount,
                    ],
                    'quantity' => 1,
                    "description" => "Purchase of " . $tour->title . ' for ' . $number_of_guests . ' people',
                ]],
                'metadata' => [
                    'client_succes_url' => $request->success,
                    'client_fail_url' => $request->failure,
                    'junket_id' => $junket_id,
                    'ip' => request()->ip(),
                    'full_name' => $full_name,
                    'number_of_guests' => $number_of_guests,
                ],
                'mode' => 'payment',
                'success_url' => route('stripe-checkout-success') . '/?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('stripe-checkout-fail') . '/?session_id={CHECKOUT_SESSION_ID}',
            ]);
            return response()->json([
                'result' => true,
                'session_id' => $session->id,
            ]);
        } catch (\Throwable $th) {
            report($th);
            return $this->fail(422, $th->getMessage());
        }
        return response()->json(['error' => 'unknown error'], 401);
    }

    public function stripeCheckoutFailure(Request $request)
    {
        try {
            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            $session = \Stripe\Checkout\Session::retrieve($request->session_id);
            $client_fail_url = base64_decode($session->metadata->client_fail_url);
             return redirect($client_fail_url);
        } catch (\Throwable $th) {
            report($th);
            return redirect('/');
        }
    }
    public function stripeCheckoutSuccess(Request $request)
    {
        try {
            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            $session = \Stripe\Checkout\Session::retrieve($request->session_id);
           
            $junket_id = $session->metadata->junket_id;
            $full_name = $session->metadata->full_name;
            $email = $session->customer_email;
            
            $client_succes_url = base64_decode($session->metadata->client_succes_url);
            if ($session->payment_status == 'paid') {
                try {
                    $tour = Tour::find($junket_id);
                    $transaction = new OutAppTransactions();
                    $transaction->tour_id  = $junket_id;
                    $transaction->client_ip_address  = $session->metadata->ip;
                    $transaction->pricing_plan_id = User::find($tour->user_id)->pricing_plan_id;
                    $transaction->amount = $session->amount_total;
                    $transaction->status = 'succeeded';
                    $transaction->payment_intent_id = $session->payment_intent;
                    $transaction->payment_host = 'stripe';
                    $transaction->details = var_export($session, true);
                    $transaction->card_holder = $session->metadata->full_name;
                    //$transaction->card_id = $payResult['card_id'];
                    $transaction->save();
                } catch (\Throwable $th) {
                    \Log::debug('Error In saveing Transaction :' . $th->getMessage());
                    report($th);
                }
                $promo_codes = [];
                $number_of_guests = $session->metadata->number_of_guests;
                for ($i = 0; $i < $number_of_guests; $i++) {
                    $temp = $this->getName(6);
                    array_push($promo_codes, $temp);
                    $tour->promoCodes()->create(['promo_code' => $temp, 'discount' => 100, 'quantity' => 1]);
                }

                try {
                    event(new RedeemJunketEvent($tour, $email, $full_name, '', $promo_codes));
                } catch (Exception $e) {
                    return redirect($client_succes_url . '&error=Email is incorrect');
                }
                return redirect($client_succes_url . '&promoCodes=' . implode(',', $promo_codes));
            }
        } catch (\Throwable $th) {
            report($th);
            return redirect('/');
        }
    }
}
