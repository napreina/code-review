<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Activity;
use App\OutAppTransactions;
use App\TransactionLog;
use App\PricingPlan;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class JunketSaleslReportResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $startDate = Carbon::parse(request()->start_date)->format('Y-m-d');
        $endDate = Carbon::parse(request()->end_date)->format('Y-m-d');
        $plan_percents = PricingPlan::PERCENTS;
        $revenue_per_junket = 0;
        $earning_per_junket = 0;
        $out_app_revenue_per_junket = 0;
        $out_app_earning_per_junket = 0;
        $out_app_revenue_per_junket += OutAppTransactions::select(['id', 'created_at', 'amount', 'pricing_plan_id'])->where('status', 'succeeded')->betweenDates($startDate, $endDate)->where('tour_id', $this->id)->sum('amount') / 100;
        $outappData = OutAppTransactions::where('status', 'succeeded')
            ->betweenDates($startDate, $endDate)
            ->where('tour_id', $this->id)
            ->get();
        $out_app_earning_per_junket += $outappData->sum(function ($t) use ($plan_percents) {
            return ($t->amount / 100) * $plan_percents[$t->pricing_plan_id]['out-app'] / 100;
        });

        $results = $this->stats()
            ->betweenDates($startDate, $endDate)
            ->orderBy('yyyymmdd')
            ->get();

        $revenue_per_tour = 0;
        $earning_per_tour = 0;

        foreach ($results as $item) {
            $google_apple_commission = 30;

            //this is for inapp earning from TransactionLog table also it is itrating for all junket $tour->stats()
            $revenues = TransactionLog::where('transaction_type', 'redemption')
                ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                ->where('tour_id', $item->tour_id)
                ->get()
                ->sum('num_tokens');

            $earning = TransactionLog::where('transaction_type', 'redemption')
                ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                ->where('tour_id', $item->tour_id)
                ->get()
                ->sum(function ($t) use (&$chartData, $google_apple_commission, $plan_percents) {

                    $revenue_split = $plan_percents[$t->pricing_plan_id]['in-app'];
                    $date = $t->created_at->format('Y-m-d');
                    $total = $t->num_tokens * $revenue_split / 100;
                    if (isset($chartData[$date])) {
                        $chartData[$date] += number_format(($total * (100 - $google_apple_commission) / 100) * -1, 2, '.', '');
                    } else {
                        $chartData[$date] = number_format(($total * (100 - $google_apple_commission) / 100) * -1, 2, '.', '');
                    }
                    return $total;
                });

            $revenue_per_tour += -1 * $revenues;
            $earning_per_tour += $earning * (100 - $google_apple_commission) / 100 * -1;
        }

        $revenue_per_junket += $revenue_per_tour;
        $earning_per_junket += number_format($earning_per_tour, 2, '.', '');
        $tmpDownloads = Activity::betweenDates($startDate, $endDate)->select('device_id')
        ->where('action', 'start_stop')
        ->where('actionable_id', $this->id)
        ->where('actionable_type', 'App\Tour')
        ->get();
        $downloads=0;
        if($tmpDownloads)
        {
            $downloads=count($tmpDownloads);
        }
        return array_merge([
            'title' => $this->title,
            'in_app_revenue' => $revenue_per_junket,
            'in_app_earning' => $earning_per_junket,
            'payout' => number_format(($earning_per_junket + $out_app_earning_per_junket), 2, '.', ''),
            'out_app_earning' => number_format(($out_app_earning_per_junket), 2, '.', ''),
            'out_app_revenue' => number_format(($out_app_revenue_per_junket), 2, '.', ''),
            'revenue' => number_format(($out_app_revenue_per_junket + $revenue_per_junket), 2, '.', ''),
            'total_earning' => number_format(($earning_per_junket + $out_app_revenue_per_junket), 2, '.', ''),
            'downloads'=>$downloads,
        ]);
    }
}
