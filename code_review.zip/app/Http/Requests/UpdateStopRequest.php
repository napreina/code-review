<?php

namespace App\Http\Requests;

class UpdateStopRequest extends CreateStopRequest
{
}
