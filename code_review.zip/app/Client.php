<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\IsUserRole;
use App\Traits\HasTours;
use Tymon\JWTAuth\Contracts\JWTSubject;

class Client extends Model implements JWTSubject
{
    use IsUserRole, HasTours;

    /**
     * The relations to eager load on every query.
     *
     * @var array
     */
    protected $with = [];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = ['user'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['company_name'];

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'clients';

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];


    public function calculateCosts($startDate,$endDate)
    {
        // return [
            
        //     'payout' =>120,
            
        // ];

        $plan_percents = PricingPlan::PERCENTS;
        $revenue_per_client = 0;
        $earning_per_client = 0;
        $out_app_revenue_per_client = 0;
        $out_app_earning_per_client = 0;
        foreach ($this->tours as $tour) {
            $out_app_revenue_per_client += (float) OutAppTransactions::where('status', 'succeeded')
            ->betweenDates($startDate, $endDate)
            ->where('tour_id', $tour->id)
            ->sum('amount');
            
            $out_app_earning_per_client += (float) OutAppTransactions::where('status', 'succeeded')
            ->betweenDates($startDate, $endDate)
            ->where('tour_id', $tour->id)
            ->get()
            ->sum(function($t) use($plan_percents){
                return round($t->amount * $plan_percents[$t->pricing_plan_id]['out-app'] / 100);
            });

            $results = $tour->stats()
                ->betweenDates($startDate, $endDate)
                ->orderBy('yyyymmdd')
                ->get();

            $revenue_per_tour = 0;
            $earning_per_tour = 0;


            foreach ($results as $item) {
                $google_apple_commission = 30;

                $revenues = TransactionLog::where('transaction_type', 'redemption')
                    ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->where('tour_id', $item->tour_id)
                    ->get()
                    ->sum('num_tokens');

                $earning = TransactionLog::where('transaction_type', 'redemption')
                    ->where('created_at', 'like', date('Y-m-d', strtotime($item->yyyymmdd)) . '%')
                    ->where('tour_id', $item->tour_id)
                    ->get()
                    ->sum(function ($t) {
                        $revenue_split = PricingPlan::find($t->pricing_plan_id)->revenue_split;
                        return $t->num_tokens * $revenue_split / 100;
                    });

                $revenue_per_tour += -1 * $revenues;
                $earning_per_tour += $earning * (100 - $google_apple_commission) / 100 * -1;
            }

            $revenue_per_client += $revenue_per_tour;
            $earning_per_client += round($earning_per_tour);
        }

        return [
            'junkets' => $this->tours()->count(),
            'in_revenue' => $revenue_per_client,
            'in_app_earning' => $earning_per_client,
            'payout' => round($earning_per_client+$out_app_earning_per_client/100),
            'out_app_earning' => $out_app_earning_per_client/100,
            'out_revenue' => number_format($out_app_revenue_per_client/100, 2),
            'revenue' => number_format($out_app_revenue_per_client/100+$revenue_per_client, 2),
        ];
    }
}
