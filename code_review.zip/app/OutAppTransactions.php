<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class OutAppTransactions extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    public function scopeBetweenDates($query, $start, $end)
    {
        if (empty($start) || empty($end)) {
            return $query;
        }

        try {
            // TODO: handle client timezones?
            $startDate = Carbon::parse($start . ' 00:00:00')->setTimezone('UTC')->format('Y-m-d H:i:s');
            $endDate = Carbon::parse($end . ' 23:59:59')->setTimezone('UTC')->format('Y-m-d H:i:s');
            return $query->whereBetween('created_at', [$startDate, $endDate]);
        } catch (\Exception $ex) {
            return $query;
        }
    }
}
