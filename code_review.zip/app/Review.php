<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * The custom attributes that are automatically appended to the model.
     *
     * @var array
     */
    protected $appends = [];

    /**
     * Relationships to always load.
     *
     * @var array
     */
    protected $with = [];

    /**
     * The attributes that should be specifically cast.
     *
     * @var array
     */
    protected $casts = [
        'rating' => 'int',
        'tour_id' => 'int',
        'user_id' => 'int'
    ];

    /**
     * Handles the model boot options.
     *
     * @return void
     */
    protected static function boot()
    {
        // update tour rating whenever a review is created
        static::saved(function ($model) {
            $rating = Review::where('tour_id', $model->tour->id)
                ->avg('rating');

            $model->tour->update(['rating' => intval($rating)]);
        });

        static::deleted(function ($model) {
            $rating = Review::where('tour_id', $model->tour->id)
                ->avg('rating');

            $model->tour->update(['rating' => intval($rating)]);
        });

        parent::boot();
    }

    // **********************************************************
    // RELATIONSHIPS
    // **********************************************************

    /**
     * Get the related Tour.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }

    /**
     * Get the User that created the review.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // **********************************************************
    // MUTATORS
    // **********************************************************

    // **********************************************************
    // QUERY SCOPES
    // **********************************************************

    /**
     * Get the reviews by the given user.
     *
     * @param Illuminate\Database\Query\Builder $query
     * @param int $user_id
     * @return Illuminate\Database\Query\Builder
     */
    public function scopeByUser($query, $user_id)
    {
        return $query->where('user_id', $user_id);
    }

    /**
     * Add query to get activity between the given dates.
     * Defaults to all results if one of the dates is empty or invalid.
     *
     * @param QueryBuilder $query
     * @param string $start
     * @param string $end
     * @return QueryBuilder
     */
    public function scopeBetweenDates($query, $start, $end)
    {
        if (empty($start) || empty($end)) {
            return $query;
        }

        try {
            // TODO: handle client timezones?
            $startDate = Carbon::parse($start . ' 00:00:00')->setTimezone('UTC')->toDateTimeString();
            $endDate = Carbon::parse($end . ' 23:59:59')->setTimezone('UTC')->toDateTimeString();
            return $query->whereBetween('created_at', [$startDate, $endDate]);
        } catch (\Exception $ex) {
            return $query;
        }
    }

    // **********************************************************
    // OTHER FUNCTIONS
    // **********************************************************


}
